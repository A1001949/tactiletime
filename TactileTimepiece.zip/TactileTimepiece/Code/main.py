# Haptic Timepiece written in CircuitPython
# Adrian Wong: Last Update March 18rd, 2019
 
import time
import board
from digitalio import DigitalInOut, Direction, Pull

# turn off built-in dotstar led to conserve energy
import adafruit_dotstar as dotstar
dot = dotstar.DotStar(board.APA102_SCK, board.APA102_MOSI, 1, brightness=0)
dot[0]=[0 , 0, 0]

# For Gemma M0, Trinket M0, Metro M0 Express, ItsyBitsy M0 Express, Itsy M4 Express
switch = DigitalInOut(board.D2)
# switch = DigitalInOut(board.D5)  # For Feather M0 Express, Feather M4 Express
# switch = DigitalInOut(board.D7)  # For Circuit Playground Express
switch.direction = Direction.INPUT
switch.pull = Pull.UP

# vibrating disc mini motor disc connected on D2
vibrating_disc = DigitalInOut(board.D1)
vibrating_disc.direction = Direction.OUTPUT

#######################################################################################################
# CHANGE THESE VALUES TO CUSTOMIZE THE WATCH ----------------------------------------------------------
#######################################################################################################

# change this value to update the time (in 24 hour, hh:mm format)
currentTime = "00:00"

# change this value to set an alarm (in 24 hour, hh:mm format)
alarmTime = "00:00"
# change alarmSet to True in order to turn on the alarm
alarmSet = False

# change this value to add a buffer in between vibrations
# the higher the value, the easier to tell the time 
timeBuffer = 0

# -----------------------------------------------------------------------------------------------------
#######################################################################################################

# arrange time in digits as hour1 hour2 : minute1 minute2 so that it appears as 00:00 or 12:24 or 23:59
hour1 = int(currentTime[0:1])
hour2 = int(currentTime[1:2])
minute1 = int(currentTime[3:4])
minute2 = int(currentTime[4:5])

ah1 = int(alarmTime[0:1])
ah2 = int(alarmTime[1:2])
am1 = int(alarmTime[3:4])
am2 = int(alarmTime[4:5])

# these are the various times in seconds of "silence" in between vibrations
# pt is silence between each digit
pt = 1 + timeBuffer
# spacing is silence between vibrations
spacing = 0.3 + timeBuffer

# respective length of the vibrations (dots vs lines)
dottime = 0.2
linetime = 0.6 + timeBuffer

# vibrate a short dot (.)
def dot():
  start_time = time.monotonic()
  curtime = time.monotonic()
  while (curtime - start_time) < dottime:
    vibrating_disc.value = True
    curtime = time.monotonic()
  vibrating_disc.value = False
  time.sleep(spacing)

# vibrate a long line (_)
def line():
  start_time = time.monotonic()
  curtime = time.monotonic()
  while (curtime - start_time) < linetime:
    vibrating_disc.value = True
    curtime = time.monotonic()
  vibrating_disc.value = False
  time.sleep(spacing)

# vibrate an alarm pattern three times
def alarm():
  for x in range(0, 3):
    dot()
    dot()
    dot()
    time.sleep(pt)

# vibrate a digit between 0 and 9
def vibrate(n):
  # 1 is . _ _ _ _
  if n == 1:
    dot()
    line()
    line()
    line()
    line()
  # 2 is . . _ _ _
  elif n == 2:
    dot()
    dot()
    line()
    line()
    line()
  # 3 is . . . _ _
  elif n == 3:
    dot()
    dot()
    dot()
    line()
    line()
  # 4 is . . . . _
  elif n == 4:
    dot()
    dot()
    dot()
    dot()
    line()
  # 5 is . . . . .
  elif n == 5:
    dot()
    dot()
    dot()
    dot()
    dot()
  # 6 is _ . . . .
  elif n == 6:
    line()
    dot()
    dot()
    dot()
    dot()
  # 7 is _ _ . . .
  elif n == 7:
    line()
    line()
    dot()
    dot()
    dot()
  # 8 is _ _ _ . .
  elif n == 8:
    line()
    line()
    line()
    dot()
    dot()
  # 9 is _ _ _ _ .
  elif n == 9:
    line()
    line()
    line()
    line()
    dot()
  # 0 is _ _ _ _ _
  elif n == 0:
    line()
    line()
    line()
    line()
    line()

# starts the seconds at 0
start_time = time.monotonic()
 
while True:
  # seconds goes up by 1 every second
  seconds = time.monotonic() - start_time
  # add to minutes every 60 seconds
  if seconds > 60:
    start_time = time.monotonic()
    minute2 += 1
  # add to tens of minutes every 10 minutes
  if minute2 > 9:
    minute1 += 1
    minute2 = 0
  # add to hours every 60 minutes
  if minute1 > 5:
    hour2 += 1
    minute1 = 0
  # add to tens of hours every 10 hours
  if hour2 > 9:
    hour1 += 1
    hour2 = 0
  # reset the clock every 24 hours
  if hour1 >= 2 and hour2 > 3:
    hour1 = 0
    hour2 = 0
    minute1 = 0
    minute2 = 0

  #check if the button is pressed
  if switch.value:
    # if the button isn't pressed, turn the button off
    vibrating_disc.value = False
  else:
    # otherwise, vibrate the current time (with buffers in between)
    vibrate(hour1)
    time.sleep(pt/2)
    vibrate(hour2)
    time.sleep(pt)
    vibrate(minute1)
    time.sleep(pt/2)
    vibrate(minute2)

  # if an alarm is set and the current time is the alarm's time, vibrate an alarm
  if alarmSet and ah1 == hour1 and ah2 == hour2 and am1 == minute1 and am2 == minute2:
    alarm()
    alarmSet = False




